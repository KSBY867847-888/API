# Changelog

### [v1.2.0]
`2019-11-22`

- fix incorrect touchmove behaviour in Firefox [\#5118](https://github.com/youzan/vant/pull/5118)

### [v1.1.0]
`2019-06-03`

- skip emulator when browser support touch event

### [v1.0.0]
`2019-05-28`

- initial release
