import Lazyload from 'vue-lazyload';

export default Lazyload;
