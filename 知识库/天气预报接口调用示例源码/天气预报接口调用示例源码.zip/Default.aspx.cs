﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using tianqi;
using System.Data;
using System.Collections; //下载于51aspx.com
public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Lite_xity.Text = "北京";
            disp_weather("北京");
        }
    }
    private void disp_weather(string city)
    {
        try
        {
            string[] arrAy = null;
            ArrayList weather = Bnn_Weather.Get_3day_weather(city);
            if (weather.Count > 0)
            {
                DateTime dt = Convert.ToDateTime(weather[3].ToString());
                Lite_Time.Text = dt.Hour.ToString() + ":" + dt.Minute.ToString() + ":" + dt.Second.ToString();
                Lite_shikuang.Text = weather[4].ToString().Replace("今日天气实况：", "");
                Lite_kongqizl.Text = weather[5].ToString().Replace("空气质量：", "");
                Lite_cont.Text = weather[6].ToString();
                arrAy = weather[7].ToString().Split(' ');
                Lite_1.Text = arrAy[0].ToString();
                Lite_1_msg.Text = arrAy[1].ToString();
                Lite_1_qw.Text = weather[8].ToString();
                Lite_1_fx.Text = weather[9].ToString();
                if (weather[10].ToString() == weather[11].ToString())
                {
                    Lite_1_img.Text = "<img src=\"images/tqimg/b_" + weather[10].ToString() + "\" width=\"50\" height=\"46\" alt='" + arrAy[0].ToString() + "" + weather[1].ToString() + "天气预报:" + arrAy[1].ToString() + "' />";
                }
                else
                {

                    Lite_1_img.Text = "<img src=\"images/tqimg/b_" + weather[10].ToString() + "\" width=\"50\" height=\"46\" alt='" + arrAy[0].ToString() + "" + weather[1].ToString() + "天气预报:" + arrAy[1].ToString() + "'/><img src=\"images/tqimg/b_" + weather[11].ToString() + "\" width=\"50\" height=\"46\" alt='" + arrAy[1].ToString().Split('转')[1].ToString() + "'/>";
                }
                arrAy = weather[12].ToString().Split(' ');
                Lite_2.Text = arrAy[0].ToString();
                Lite_2_msg.Text = arrAy[1].ToString();
                Lite_2_qw.Text = weather[13].ToString();
                Lite_2_fx.Text = weather[14].ToString();
                if (weather[15].ToString() == weather[16].ToString())
                {
                    Lite_2_img.Text = "<img src=\"images/tqimg/b_" + weather[15].ToString() + "\" width=\"50\" height=\"46\" alt='" + arrAy[0].ToString() + "" + weather[1].ToString() + "天气预报:" + arrAy[1].ToString() + "'/>";
                }
                else
                {
                    Lite_2_img.Text = "<img src=\"images/tqimg/b_" + weather[15].ToString() + "\" width=\"50\" height=\"46\" alt='" + arrAy[0].ToString() + "" + weather[1].ToString() + "天气预报:" + arrAy[1].ToString() + "' /><img src=\"images/tqimg/b_" + weather[16].ToString() + "\" width=\"50\" height=\"46\" alt='" + arrAy[1].ToString().Split('转')[1].ToString() + "' />";
                }

                arrAy = weather[17].ToString().Split(' ');
                Lite_3.Text = arrAy[0].ToString();
                Lite_3_msg.Text = arrAy[1].ToString();
                Lite_3_qw.Text = weather[18].ToString();
                Lite_3_fx.Text = weather[19].ToString();
                if (weather[20].ToString() == weather[21].ToString())
                {
                    Lite_3_img.Text = "<img src=\"images/tqimg/b_" + weather[20].ToString() + "\" width=\"50\" height=\"46\" alt='" + arrAy[0].ToString() + "" + weather[1].ToString() + "天气预报:" + arrAy[1].ToString() + "'/>";
                }
                else
                {
                    Lite_3_img.Text = "<img src=\"images/tqimg/b_" + weather[20].ToString() + "\" width=\"50\" height=\"46\" alt='" + arrAy[0].ToString() + "" + weather[1].ToString() + "天气预报:" + arrAy[1].ToString() + "' /><img src=\"images/tqimg/b_" + weather[21].ToString() + "\" width=\"50\" height=\"46\" alt='" + arrAy[1].ToString().Split('转')[1].ToString() + "' />";
                }

                arrAy = weather[22].ToString().Split(' ');
                Lite_4.Text = arrAy[0].ToString();
                Lite_4_msg.Text = arrAy[1].ToString();
                Lite_4_qw.Text = weather[23].ToString();
                Lite_4_fx.Text = weather[24].ToString();
                if (weather[25].ToString() == weather[26].ToString())
                {
                    Lite_4_img.Text = "<img src=\"images/tqimg/b_" + weather[25].ToString() + "\" width=\"50\" height=\"46\" alt='" + arrAy[0].ToString() + "" + weather[1].ToString() + "天气预报:" + arrAy[1].ToString() + "'/>";
                }
                else
                {
                    Lite_4_img.Text = "<img src=\"images/tqimg/b_" + weather[25].ToString() + "\" width=\"50\" height=\"46\" alt='" + arrAy[0].ToString() + "" + weather[1].ToString() + "天气预报:" + arrAy[1].ToString() + "' /><img src=\"images/tqimg/b_" + weather[26].ToString() + "\" width=\"50\" height=\"46\" alt='" + arrAy[1].ToString().Split('转')[1].ToString() + "' />";
                }

                arrAy = weather[27].ToString().Split(' ');
                Lite_5.Text = arrAy[0].ToString();
                Lite_5_msg.Text = arrAy[1].ToString();
                Lite_5_qw.Text = weather[28].ToString();
                Lite_5_fx.Text = weather[29].ToString();
                if (weather[30].ToString() == weather[31].ToString())
                {
                    Lite_5_img.Text = "<img src=\"images/tqimg/b_" + weather[30].ToString() + "\" width=\"50\" height=\"46\" alt='" + arrAy[0].ToString() + "" + weather[1].ToString() + "天气预报:" + arrAy[1].ToString() + "'/>";
                }
                else
                {
                    Lite_5_img.Text = "<img src=\"images/tqimg/b_" + weather[30].ToString() + "\" width=\"50\" height=\"46\" alt='" + arrAy[0].ToString() + "" + weather[1].ToString() + "天气预报:" + arrAy[1].ToString() + "' /><img src=\"images/tqimg/b_" + weather[31].ToString() + "\" width=\"50\" height=\"46\" alt='" + arrAy[1].ToString().Split('转')[1].ToString() + "' />";
                }

            }
        }
        catch (Exception)
        {
            Page.ClientScript.RegisterClientScriptBlock(GetType(), "asdf", "<script>alert('您提供的城市查不到')</script>");
        }

    }

    public class Bnn_Weather
    {
        public static ArrayList Get_3day_weather(string CityName)
        {
            //接口地址：http://webservice.webxml.com.cn/WebServices/WeatherWS.asmx
            tianqi.WeatherWS weat = new WeatherWS();
            string[] strarr = weat.getWeather(CityName, "");
            ArrayList list = new ArrayList();
            int listLength = strarr.Length;
            if (listLength > 0)
            {
                for (int i = 0; i < listLength; i++)
                {
                    list.Add(strarr[i]);
                }
            }
            
            return list;
        }
    }
}
