
// STUB
module.exports = require('vue');
