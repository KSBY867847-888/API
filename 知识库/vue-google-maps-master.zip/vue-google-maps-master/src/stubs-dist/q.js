
// STUB
module.exports = require('q');
