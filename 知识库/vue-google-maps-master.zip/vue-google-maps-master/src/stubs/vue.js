
module.exports = window.Vue;
