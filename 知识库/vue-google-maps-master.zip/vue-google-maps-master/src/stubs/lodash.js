
module.exports = window._;
