<!-- _coverpage.md -->

![logo](/assets/images/logo.png)

## vue-amap  |  基于 Vue 2.x 与高德的地图组件

- 数据状态与地图状态单向绑定
- 开发者无需关心地图的具体操作

[GitHub](https://github.com/ElemeFE/vue-amap/)
[文档](/zh-cn/introduction/install)

![color](#e4fff7)
