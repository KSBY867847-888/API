
<!-- 问题模板，最好复现下 提供基础模板 https://jsfiddle.net/4p4pe2w6/   -->

## 问题

### VueAMap 版本

### OS/Browsers version

### Vue 版本

### 复现地址

### 预期

### 实际

## feature request

