import { Point, Copyright } from './base/common'
import { BaseControl } from './base/base-control'


export declare class Copyright extends BaseControl {
  copyright: Copyright[]
}