import { BaseControl } from './base/base-control'

export declare class Scale extends BaseControl {}