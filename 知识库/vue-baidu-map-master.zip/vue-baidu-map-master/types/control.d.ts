import { BaseControl } from './base/base-control'

export declare class Control extends BaseControl {}