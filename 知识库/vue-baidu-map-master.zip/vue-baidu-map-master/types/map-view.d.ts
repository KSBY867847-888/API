
export declare class MapView {
}