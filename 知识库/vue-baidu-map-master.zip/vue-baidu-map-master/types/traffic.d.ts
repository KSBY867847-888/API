import { PredictDate } from './base/common'

export declare class Traffic {
  /**
   * 预测日期
   */
  predictDate: PredictDate
}