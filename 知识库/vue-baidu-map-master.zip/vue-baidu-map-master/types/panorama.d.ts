import { BaseControl } from './base/base-control'

export declare class Panorama extends BaseControl {}