
export declare class Menu {
  /**
   * 菜单宽度
   */
  width: number
}