# VUE BAIDU MAP

<p align="center"><img src="//dafrok.github.io/vue-baidu-map/favicon.png" width="200px"></p>

<p align="center">基于 VUE 2.x 的百度地图组件</p>

[![npm](https://img.shields.io/npm/v/vue-baidu-map.svg)]()
[![Travis](https://img.shields.io/travis/Dafrok/vue-baidu-map.svg)]()
[![license](https://img.shields.io/github/license/dafrok/vue-baidu-map.svg)]()
[![Package Quality](https://camo.githubusercontent.com/288996eeba7c6433cb9a72caf2385913f2ceebb2/687474703a2f2f6e706d2e7061636b6167657175616c6974792e636f6d2f736869656c642f7675652d62616964752d6d61702e737667)](http://packagequality.com/#?package=vue-baidu-map)
[![npm](https://img.shields.io/npm/dm/vue-baidu-map.svg)]()

## 贡献

[贡献指南](https://github.com/Dafrok/vue-baidu-map/blob/master/CONTRIBUTING.md)

## 协议

[MIT 许可证](//opensource.org/licenses/MIT)

版权所有 (c) 2016-至今 Dafrok <o.o@mug.dog>
