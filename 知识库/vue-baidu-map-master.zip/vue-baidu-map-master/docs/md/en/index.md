# VUE BAIDU MAP

<p align="center"><img src="//dafrok.github.io/vue-baidu-map/favicon.png" width="200px"></p>

<p align="center">Baidu Map components for Vue 2.x</p>

[![npm](https://img.shields.io/npm/v/vue-baidu-map.svg)]()
[![Travis](https://img.shields.io/travis/Dafrok/vue-baidu-map.svg)]()
[![license](https://img.shields.io/github/license/dafrok/vue-baidu-map.svg)]()
[![Package Quality](https://camo.githubusercontent.com/288996eeba7c6433cb9a72caf2385913f2ceebb2/687474703a2f2f6e706d2e7061636b6167657175616c6974792e636f6d2f736869656c642f7675652d62616964752d6d61702e737667)](http://packagequality.com/#?package=vue-baidu-map)
[![npm](https://img.shields.io/npm/dm/vue-baidu-map.svg)]()

## Contributing

[Contributing Guide](https://github.com/Dafrok/vue-baidu-map/blob/master/CONTRIBUTING.md)

## License

[MIT License](https://opensource.org/licenses/MIT)

Copyright (c) 2016-present, Dafrok <o.o@mug.dog>
