# Installation

## NPM

```bash
$ npm install vue-baidu-map --save
```

## CDN

```html
<script src="https://unpkg.com/vue-baidu-map"></script>
```