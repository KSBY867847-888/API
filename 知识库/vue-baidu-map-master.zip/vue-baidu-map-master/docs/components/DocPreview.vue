<template lang="pug">
md-whiteframe
  slot
</template>
