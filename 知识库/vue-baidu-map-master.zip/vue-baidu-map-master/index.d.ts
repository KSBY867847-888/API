/// <reference types="typescript" />

declare module 'vue-baidu-map'