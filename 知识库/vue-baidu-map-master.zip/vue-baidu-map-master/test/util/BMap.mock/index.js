import Map from './Map.js'

export default {
  Map
}