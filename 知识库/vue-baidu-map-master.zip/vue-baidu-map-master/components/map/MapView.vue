<template>
<div></div>
</template>

<script>
export default {
  name: 'bm-view'
}
</script>
